


function clickSubmit (event) {
  event.preventDefault()
  var item = $("#inputText").val();
  $("#listItems").push("<li>"+item+"</li>")
  $("#inputText").val("");
  console.log(item)
  };